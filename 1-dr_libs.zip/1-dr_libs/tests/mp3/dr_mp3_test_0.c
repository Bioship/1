#define DR_MP3_IMPLEMENTATION
#include "../../dr_mp3.h"

#include "../common/dr_common.c"

int main(int argc, char** argv)
{
    (void)argc;
    (void)argv;
    return 0;
}

