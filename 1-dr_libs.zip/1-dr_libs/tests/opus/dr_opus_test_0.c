#define DR_OPUS_IMPLEMENTATION
#include "../../wip/dr_opus.h"

int main(int argc, char** argv)
{
    (void)argc;
    (void)argv;
    return 0;
}