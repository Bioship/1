#define MS_BITFIELDS 1
#include "95_bitfields.c"
