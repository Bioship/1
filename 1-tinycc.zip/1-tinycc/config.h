#define TCC_VERSION "0.9.27"
#ifdef TCC_TARGET_X86_64
  #define TCC_LIBTCC1 "libtcc1-64.a"
#else
  #define TCC_LIBTCC1 "libtcc1-32.a"
#endif
